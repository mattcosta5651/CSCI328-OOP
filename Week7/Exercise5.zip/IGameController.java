public interface IGameController
{
  public void startGame();
}
